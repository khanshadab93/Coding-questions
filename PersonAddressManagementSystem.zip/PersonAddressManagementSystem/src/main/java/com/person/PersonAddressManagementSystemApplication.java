package com.person;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(scanBasePackages = { "com.person.service", "com.person.repo" })
@ComponentScan({ "com.person", "com.person.service", "com.person.repo" })
@EntityScan("com.person.entity")
public class PersonAddressManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonAddressManagementSystemApplication.class, args);
	}

}
