package com.person.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.person.entity.Person;
import com.person.repo.PersonRepo;

@Service
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonRepo personRepo;

	public String fetchById(Integer id) {
		Optional<Person> person;
		if (!checkIfExists(id)) {
			return "Person not present with this ID";
		}
		try {
			person = personRepo.findById(id);
		} catch (Exception e) {
			return e.getMessage();
		}
		return (person.toString()).replace("Optional[", "").replace("]", "");
	}

	public String deleteById(Integer id) {
		if (!checkIfExists(id)) {
			return "Person not present with this ID";
		}
		try {
			personRepo.deleteById(id);
		} catch (Exception e) {
			return e.getMessage();
		}
		return "Deleted successfully";
	}

	public String updatePerson(Person person, String flag) {
		if (flag.equals("insert")) {
			if (checkIfExists(person.getId())) {
				return "Person already present with this ID";
			}
		} else if (flag.equals("update")) {
			if (!checkIfExists(person.getId())) {
				return "Person not present with this ID";
			}
		}
		try{
			personRepo.save(person);
		}
		catch(Exception e) {
			return e.getMessage();
		}
		if (flag.equals("insert")) {
			return "Inserted Successfully";
		} else if (flag.equals("update")) {
			return "Updated Successfully";
		}
		
		return null;
	}

	private boolean checkIfExists(Integer id) {
		return personRepo.existsById(id);
	}
}
