package com.person.service;

import java.util.Optional;

import com.person.entity.Person;

public interface PersonService {

	public String fetchById(Integer id);
	public String deleteById(Integer id);
	public String updatePerson(Person person, String flag);
}
